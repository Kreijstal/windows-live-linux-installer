prefix=$cmdpath
clear
echo
echo Prefix from bootefi.sh is $prefix
configfile ($root)/efi/grub2win/g2bootmgr/gnugrub.efisetup.cfg 
echo
echo